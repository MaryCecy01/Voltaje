package Voltaje;
import java.util. Scanner;
public class voltaje {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int cant=0, min=0, max=0, vol=0, count=1;
		boolean band=true;
		System.out.println(" Ingrese cantidad de voltajes");
		cant=tc.nextInt();
		
		
		while(count<=cant) {
			System.out.println(" Ingrese voltaje");
			vol=tc.nextInt();
			count=count+1;
			
			if(band=true) {
				max=vol;
				band=false;
			}
			else {
				if(vol>max){
					max=vol;
				}else {
						if(vol<min){
							min=vol;
							
						}
					}
			}
		}
			
			
			
		

		System.out.println(" Voltaje maximo:"+max);
		System.out.println(" Voltaje minimo:"+min);
	}

}
