package Voltaje;
import java.util. Scanner;
public class Volyajee {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int count=1,vol,cant;
		
		System.out.println(" Ingrese cantidad de voltajes");
		cant=tc.nextInt();
		
		while(count<=cant) {
			System.out.println(" Ingrese voltaje");
			vol=tc.nextInt();
			count=count+1;
			
		    
		 

		
		}
	}

}
